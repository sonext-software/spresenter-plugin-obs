// Public domain types exposed to plugins. These mirror the shapes the host
// returns from the API surface. They are intentionally loose where the app's
// internal model is dynamic — plugins should treat unknown fields defensively.

export interface OutputSummary {
  index: number;
  name: string;
  width?: number;
  height?: number;
  disabledLayers: number[];
}

export interface LayerSummary {
  index: number;
  name?: string;
  icon?: string;
}

export interface LayerState {
  show: boolean;
  opacity: number;
  blend: string;
  transitionMs?: number;
  [key: string]: unknown;
}

export interface Asset {
  guid: string;
  type: string;
  title?: string;
  author?: string;
  parent_guid?: string | null;
  category?: string | null;
  [key: string]: unknown;
}

export interface AssetFilters {
  type?: string;
  category?: string;
  /** undefined = no folder filter; null = category root; string = inside folder. */
  parent?: string | null;
}

export interface Lyrics {
  lyrics: string[];
  sections: unknown[];
  groups: unknown[];
  [key: string]: unknown;
}

export interface Theme {
  [key: string]: unknown;
}

/** A single unit of content rendered on a layer. */
export interface Presentation {
  title?: string;
  asset: Asset;
  theme?: Theme;
  props?: Record<string, unknown>;
}

export interface MediaState {
  playing: boolean;
  loop: boolean;
  time: number;
}

export interface TimerState {
  endTime: number | null;
  remainingMs: number | null;
  running: boolean;
  allowNegative: boolean;
  mode: 'duration' | 'target' | null;
  format: string;
}

export interface EventSummary {
  id: string;
  name?: string;
  [key: string]: unknown;
}

export type ActiveEvent = Record<string, unknown>;

/** Real-time patch applied to a live theme element (by id), without reloading. */
export interface ElementPatch {
  /** Replace the element's text (TEXT) — goes through the template/markdown pipeline. */
  text?: string;
  /** Raw HTML: render the element freely, bypassing template/markdown. */
  html?: string;
  /** Merge into the element's css (color, size, position, …). */
  css?: Record<string, string | number>;
  /** Toggle visibility. */
  visible?: boolean;
  /** Swap the source (IMAGE/VIDEO). */
  src?: string;
}

/** Chainable handle to a live element — modify it freely (text, style, html…). */
export interface ElementHandle {
  readonly id: string;
  /** Apply an arbitrary patch. */
  patch(p: ElementPatch): ElementHandle;
  setText(text: string): ElementHandle;
  setHtml(html: string): ElementHandle;
  setStyle(css: Record<string, string | number>): ElementHandle;
  setSrc(src: string): ElementHandle;
  show(): ElementHandle;
  hide(): ElementHandle;
}

export type ApiScope =
  | 'outputs:read'
  | 'live:read'
  | 'live:write'
  | 'assets:read'
  | 'media:read'
  | 'media:write'
  | 'events:read'
  | 'timer:read'
  | 'timer:write'
  /** Só-plugin: abrir conexões de rede (WebSocket) via `spresenter.net`. */
  | 'net:connect';

export interface PluginPanelDef {
  id: string;
  title: string;
  icon?: string;
}

export interface PluginManifest {
  id: string;
  name: string;
  version: string;
  description?: string;
  author?: string;
  minAppVersion?: string;
  sdk?: string;
  main: string;
  ui?: string;
  permissions: ApiScope[];
  panels?: PluginPanelDef[];
  /** Start the logic process at boot (needed for automation nodes / background). */
  background?: boolean;
}

/** A field in an automation node's config form. */
export interface AutomationNodeField {
  type: 'string' | 'number' | 'boolean' | 'select';
  label?: string;
  default?: unknown;
  hint?: string;
  /** Options for `type: 'select'` (string or `{ value, label }`). */
  options?: (string | { value: string; label: string })[];
}

/** Definition passed to spresenter.automation.registerNode(). */
export interface AutomationNodeDef {
  /** Unique within the plugin. */
  id: string;
  name: string;
  description?: string;
  /** Category key in the "add node" menu. Defaults to 'plugins'. Use a key
   *  declared via `registerCategory` to group under a custom section. */
  category?: string;
  config?: Record<string, AutomationNodeField>;
  /** Runs when an automation fires this node. Receives the trigger payload
   *  and the node's configured values. */
  execute: (payload: any, config: any) => void | Promise<void>;
}

/** A custom category for the "add node" menu, declared via registerCategory(). */
export interface AutomationCategoryDef {
  /** Grouping key referenced by node `category`. */
  key: string;
  /** Human label shown in the menu. */
  label: string;
  /** lucide icon name (renderer allowlist; fallback = puzzle). */
  icon?: string;
}

/** A field on a trigger, used to filter which events run the automation. */
export interface AutomationTriggerField {
  /** Payload key this field reads/filters on. */
  name: string;
  label?: string;
  type: 'string' | 'number' | 'boolean' | 'select';
  /** Options for `type: 'select'`. */
  options?: (string | { value: string; label: string })[];
}

/** Definition passed to spresenter.automation.registerTrigger(). The plugin
 *  fires it at runtime with emitTrigger(id, payload). */
export interface AutomationTriggerDef {
  /** Unique within the plugin. */
  id: string;
  name: string;
  description?: string;
  /** Category key in the "add node" menu. Defaults to 'plugins'. */
  category?: string;
  /** Fields exposed as per-field filters on the trigger node. */
  fields?: AutomationTriggerField[];
  /** Example payload shown in the editor. */
  samplePayload?: Record<string, unknown>;
}
